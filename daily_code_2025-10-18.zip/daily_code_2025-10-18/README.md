# Daily Code — 2025-10-18

Repo, işe alım yöneticilerinin baktığında **dolu**, **düzenli** ve **test odaklı** görünmesi için hazırlandı.
Bugünün paketi üç farklı mini-çalışma içerir: algoritma, metin işleme ve JSON dönüşümü.

## Hızlı Başlangıç
```bash
python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pytest -q
```
