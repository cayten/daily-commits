
from days.Y2025_10_18.alg_two_sum.solution import two_sum

def test_basic():
    assert two_sum([2,7,11,15], 9) == (0,1)

def test_no_pair():
    assert two_sum([1,2,3], 100) == (-1,-1)

def test_duplicates():
    assert two_sum([3,3], 6) == (0,1)
