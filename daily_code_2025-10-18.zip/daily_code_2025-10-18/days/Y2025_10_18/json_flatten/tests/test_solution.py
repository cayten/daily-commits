
import json
from days.Y2025_10_18.json_flatten.solution import flatten, to_csv

def test_flatten_and_csv():
    items = [
        {"id": 1, "name": "Ada", "meta": {"age": 10}},
        {"id": 2, "name": "Turing", "meta": {"age": 41}},
    ]
    rows = flatten(items)
    assert rows == [{"id":1,"name":"Ada","age":10},{"id":2,"name":"Turing","age":41}]
    csv = to_csv(rows).splitlines()
    assert csv[0] == "id,name,age"
    assert csv[1] == "1,Ada,10"
    assert csv[2] == "2,Turing,41"
