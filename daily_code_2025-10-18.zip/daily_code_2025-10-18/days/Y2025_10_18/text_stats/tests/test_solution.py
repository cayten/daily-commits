
from days.Y2025_10_18.text_stats.solution import text_stats

def test_counts():
    w, c, u = text_stats("Merhaba dunya merhaba")
    assert w == 3 and u == 2
    assert c == len("Merhaba dunya merhaba")
