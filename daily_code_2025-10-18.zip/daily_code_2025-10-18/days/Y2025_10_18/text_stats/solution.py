
import sys

def text_stats(s: str):
    words = [w for w in s.strip().split() if w]
    words_lower = [w.lower() for w in words]
    chars = len(s)
    unique = len(set(words_lower))
    return len(words), chars, unique

def main():
    data = sys.stdin.read()
    w, c, u = text_stats(data)
    print(f"words={w} chars={c} unique={u}")

if __name__ == "__main__":
    main()
